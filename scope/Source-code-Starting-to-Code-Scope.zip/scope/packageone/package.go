package packageone

var privateVar = "I am private"
var PublicVar = "I am public (or exported)"

func notExported() {

}

func Exported() {
	
}